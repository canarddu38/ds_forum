<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

// Help Section 1
$l['s1_name'] = "User Maintenance";
$l['s1_desc'] = "Basic instructions for maintaining a forum account.";

// Help Section 2
$l['s2_name'] = "Posting";
$l['s2_desc'] = "Posting, replying, and basic usage of forum.";
